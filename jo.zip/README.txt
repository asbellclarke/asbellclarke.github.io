Instructions for Jo-pardy! code kit.

Extract All
- unzip contents of .zip

Note: There are three files of note. One that is just a selection for part 1 or 2 (of the game) and then one for each part, 1 and 2. All three of these files are different directories and all three use the same name: index.html

Navigate to directory: kit / 1 /
- double click to index.html

This should open in your default browser. That is the end result. That is the whole code running on your computer.

Follow the following steps to edit the text.

The next step is to install a script editor for this hypertext file format. Then just a basic understanding of search and replace will get you through the chaos of the code. No script editing required. Of course, you do need to be able to input your questions and answers.

So, install a script editor. I have two recommendations. Both free. Apple has an app for all sort of development called Xcode. You can find that in the Appstore. Or your can download the editor that I have used, Atom, which is archived for mac at the following link.

https://github.com/atom/atom/releases/download/v1.60.0/atom-mac.zip

So, script editor installed.

Navigate back to directory: kit / 1 /
- right click (or hold control and click) the index.html
- choose instead to open with Atom or Xcode

That's a bingo. A general glaze through the file should give you a sense of the order of things. You will see, in the whole, there are five big groups of six smaller groups of paired questions and answers. This big picture is worth reviewing. There are five big groups, one for each of the Jopardy! point values, for example: 200, 400, 600, 800, 1000. You will see these numbers repeated in the code. You need not edit any of those. What is important to recognize is that, in the code, the main grouping is based on Jopardy! point value, and not Jopardy! category. The categories are the so called smaller groups. So, for example, category A will have a question in each of the five big groups. These are identified, for example, as A1, A2, A3, A4 and A5. Lastly, each smaller group, for example, A, in each big group, for example, 1, so for this example A1 then breaks into a paired question and answer.

One way to approach this task is to curate your questions and answers in a separate document. Six categories. Five questions per category. And twice for the two parts. Label your categories with letters and number your pairs 1 through 5. And then it's all about search and replace.

Two templates are included at the bottom of this text. One as a simple visual breakdown of the code. A second as a simple framework to actually get started with categories and questions and so on.

So, back to Atom or Xcode with the Jopardy! code open.
- press [CTRL] + [F]
- search for "Question A1?"
- replace that text with your question text for A1 (the actual question mark at the end is optional)
- below, you will see the text "Answer A1"
  - alternatively, search for "Answer A1"
- replace that with your answer for A1

Save the file. Reload the page (or open it again) in your browser. See that your edits were applied successfully, with the question and answer in the correct order.

Repeat search and replace for the rest of the questions and answers. Save and check your work every so often. The categories and groups and questions and answers are easily boggled up. So keep your separate file intact as you search and replace text in the code, then if the code gets boggled in the browser, you can go back to the beginning: extract all from the .zip and restart.


--
Template of code. Note: this is the way the code is laid out. This is not grouped by category and may not be an ideal template when coming up with questions and answers and so on.

Question A1 -
Answer A1 -

Question B1 -
Answer B1 -

Question C1 -
Answer C1 -

Question D1 -
Answer D1 -

Question E1 -
Answer E1 -

Question F1 -
Answer F1 -


Question A2 -
Answer A2 -

Question B2 -
Answer B2 -

Question C2 -
Answer C2 -

Question D2 -
Answer D2 -

Question E2 -
Answer E2 -

Question F2 -
Answer F2 -


Question A3 -
Answer A3 -

Question B3 -
Answer B3 -

Question C3 -
Answer C3 -

Question D3 -
Answer D3 -

Question E3 -
Answer E3 -

Question F3 -
Answer F3 -


Question A4 -
Answer A4 -

Question B4 -
Answer B4 -

Question C4 -
Answer C4 -

Question D4 -
Answer D4 -

Question E4 -
Answer E4 -

Question F4 -
Answer F4 -


Question A5 -
Answer A5 -

Question B5 -
Answer B5 -

Question C5 -
Answer C5 -

Question D5 -
Answer D5 -

Question E5 -
Answer E5 -

Question F5 -
Answer F5 -


--
Template in practice. I start with this kind of format. And then try to be careful about transposing the lists into the code, as ordered above.

Category A
- Question A1 - Answer A1
- Question A2 - Answer A2
- Question A3 - Answer A3
- Question A4 - Answer A4
- Question A5 - Answer A5

Category B
- Question B1 - Answer B1
- Question B2 - Answer B2
- Question B3 - Answer B3
- Question B4 - Answer B4
- Question B5 - Answer B5

Category C
- Question C1 - Answer C1
- Question C2 - Answer C2
- Question C3 - Answer C3
- Question C4 - Answer C4
- Question C5 - Answer C5

Category D
- Question D1 - Answer D1
- Question D2 - Answer D2
- Question D3 - Answer D3
- Question D4 - Answer D4
- Question D5 - Answer D5

Category E
- Question E1 - Answer E1
- Question E2 - Answer E2
- Question E3 - Answer E3
- Question E4 - Answer E4
- Question E5 - Answer E5

Category F
- Question F1 - Answer F1
- Question F2 - Answer F2
- Question F3 - Answer F3
- Question F4 - Answer F4
- Question F5 - Answer F5

Last of all, the categories !
- search "Category A Title"
- replace with your title (and you will see the rest of the category titles listed immediately below).
- edit away.

Any questions, let me know. Or not. No pressure.
